const mongoose = require('mongoose');

const TempleSchema = new mongoose.Schema({
  fname: { type: String, required: true },
  mobile: { type: String, required: true },
  email: { type: String, required: true },
  city: { type: String, required: true },
  amount: { type: Number, required: true },
  image: { type: String },
  paid: { type: Boolean, default: false }
});

const TempleModel = mongoose.model("Donation", TempleSchema);

module.exports = TempleModel;




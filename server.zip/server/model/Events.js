const mongoose=require('mongoose')

const EventSchema=new mongoose.Schema({
    event:String,
    date:String,
    time:String,
    message:String
})

const EventModel=mongoose.model('Events',EventSchema)

module.exports=EventModel
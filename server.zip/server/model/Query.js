const mongoose=require('mongoose')

const QuerSchema=new mongoose.Schema({
    name:String,
    phone:String,
    message:String
})

const QueryModel=mongoose.model("Query",QuerSchema)

module.exports=QueryModel
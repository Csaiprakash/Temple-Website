const mongoose=require('mongoose')

const DarshanSchema=new mongoose.Schema({
    name: { type: String, required: true },
  ticket: { type: Number, required: true },
  email: { type: String, required: true },
  mobile: { type: String, required: true },
  date: { type: String, required: true },
  slot: { type: String, required: true },
  amount: { type: Number, required: true },
  paid:{type:Boolean,default:false}
})

const DarshanModel=mongoose.model('darshan',DarshanSchema)
module.exports=DarshanModel
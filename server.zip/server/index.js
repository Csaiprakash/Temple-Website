const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const TempleModel = require('./model/Amount');
const DarshanModel = require('./model/Darshan');
const QueryModel=require('./model/Query')
const EventModel=require('./model/Events')
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const twilio = require('twilio'); 
const QRCode = require('qrcode');
const app = express();

app.use(express.json());
app.use(cors());

const twilioClient = twilio('AC32aca20049c459e10754534171e3f217', '6ce36210794bcdf49d336ed9f54c58ac');


const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

mongoose.connect('mongodb+srv://csaiprakash77:omsai2244@cluster0.eb3gxv4.mongodb.net/Temple', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB connection error:", err));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'build')));
app.use('/uploads', express.static(uploadDir));

app.post('/donation', upload.single('image'), async (req, res) => {
  const { fname, mobile, email, city, amount } = req.body;
  const image = req.file ? req.file.filename : null;

  const donationData = {
    fname,
    mobile,
    email,
    city,
    amount,
    image,
    paid: false
  };

  try {
    const donation = await TempleModel.create(donationData);
    const upiId = '8309614542@ybl'; // Replace with your UPI ID
    const qrData = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(fname)}&am=${amount}&cu=INR`;

    console.log('QR Data:', qrData); // Log QR data for debugging
    const qrCode = await QRCode.toDataURL(qrData);

    res.json({ donation, qrCode });
  } catch (err) {
    console.error('Failed to submit donation:', err);
    res.status(500).json({ error: "Failed to submit donation", details: err.message });
  }
});






app.post('/darshan', async (req, res) => {
  const { name, ticket, email, mobile, date, slot, amount } = req.body;

  const darshanData = {
    name,
    ticket,
    email,
    mobile,
    date,
    slot,
    amount,
    paid: false
  };

  try {  
    // Save Darshan data to the database
    const darshan = await DarshanModel.create(darshanData);

    // Generate QR code
    const upiId = '8309614542@ybl'; // Replace with your UPI ID
    const qrData = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&am=${amount}&cu=INR`;
    const qrCode = await QRCode.toDataURL(qrData);
    res.json({ darshan, qrCode });
  } catch (err) {
    console.error('Failed to submit darshan details:', err);
    res.status(500).json({ error: 'Failed to submit darshan details' });
  }
});



const twilioPhoneNumber = '+15087196669';

async function sendSMS(to, message) {
  try {
    await twilioClient.messages.create({
      body: message,
      from: twilioPhoneNumber, // Use your Twilio phone number here
      to: to,
    });
    console.log('SMS sent successfully');
  } catch (error) {
    console.error('Error sending SMS:', error);
  }
}

// Add a new route to handle sending SMS
app.post('/sms', async (req, res) => {
  const { name, mobile, date, slot } = req.body;

  try {
    // Construct SMS message
    const message = `Dear ${name}, Your Darshan booking for ${date} at ${slot} has been confirmed. Thank you!, From NaraSimha Swami Devasthanam,Kadiri`;

    // Send SMS
    await sendSMS(mobile, message);

    res.sendStatus(200); // Send success response
  } catch (error) {
    console.error('Error sending SMS:', error);
    res.status(500).json({ error: 'Failed to send SMS' });
  }
});



app.post('/contact', async (req, res) => {
  const { name, phone, message } = req.body;

  try {
    const result = await QueryModel.create({ name, phone, message });
    res.json(result);
  } catch (error) {
    console.error('Error creating query:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.post('/addevent',(req,res)=>{
  const {event,date,time,message}=req.body;
  const result=EventModel.create({event,date,time,message})
  res.json(result)
})


app.get('/events', async (req, res) => {
  try {
    const events = await EventModel.find().select('event date time message');
    res.json({ success: true, events }); // Ensure the response contains an array
  } catch (err) {
    res.status(500).json({ success: false, error: "Failed to fetch events", details: err.message });
  }
});

  
app.get('/donations', async (req, res) => {
  try {
    const donations = await TempleModel.find().select('fname city amount image');
    res.json(donations);
  } catch (err) {
    console.error('Failed to fetch donations:', err);
    res.status(500).json({ error: "Failed to fetch donations", details: err.message });
  }
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
 
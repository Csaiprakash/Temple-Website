import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Navbar2 from './components/Navbar2';
import AddEvent from './pages/AddEvent';
import AdmLogin from './pages/AdmLogin';
import Contact from './pages/Contact';
import Darshan from './pages/Darshan';
import Donars from './pages/Donars';
import Donation from './pages/Donation';
import Events from './pages/Events';
import Home from './pages/Home';
import Head from './components/Head';
import './App.css';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <BrowserRouter>
      <div>
        <Head />
        {isLoggedIn ? <Navbar2 /> : <Navbar />}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/admlogin" element={<AdmLogin setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/donation" element={<Donation />} />
          <Route path="/donars" element={<Donars />} />
          <Route path="/events" element={<Events />} />
          <Route path="/darshan" element={<Darshan />} />
          <Route path="/contact" element={<Contact />} />
          {isLoggedIn && (
            <>
              <Route path="/addevent" element={<AddEvent />} />
            </>
          )}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;

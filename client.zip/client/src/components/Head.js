import React from 'react'
import '../components/Head.css'
import Temple from '../Images/Temple.webp'
const Head=()=>{
    return(
        <div className='container'>
            <img src={Temple} alt='here'/>
            <h1>
                <span>Kadiri Lakshmi Narasimha Swami</span>
                <span>Devasathanam</span>
            </h1>
  
        </div>

    )
} 
export default Head
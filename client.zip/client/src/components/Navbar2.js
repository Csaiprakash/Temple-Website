import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar2 = () => {
  return (
    <nav>
      <Link to='/'><i className="fa fa-home"></i></Link>
      <ul>
        <li><Link to='/addevent'>Add Event</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar2;

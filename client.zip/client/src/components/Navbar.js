import React from 'react'
import './Navbar.css'
const Navbar=()=>{
    return(
        <nav>
            <a href='/'><i class="fa fa-home"></i></a>
            <ul>
                <li><a href='/'>Home</a></li>
                <li><a href='admlogin'>Admin Login</a></li>
                <li><a href='donation'>Donation</a></li>
                <li><a href='donars'>Donars</a></li>
                <li><a href='events'>Events</a></li>
                <li><a href='darshan'>Darshan</a></li>
                <li><a href='contact'>Contact</a></li>
            </ul>  
        </nav> 
    )
}
export default Navbar
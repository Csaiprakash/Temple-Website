import React, { useEffect, useState } from 'react';
import './Events.css';
import axios from 'axios';

const Events = () => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/events')
      .then(response => {
        const currentEvents = response.data.events || [];
        // Filter out past events
        const filteredEvents = currentEvents.filter(event => new Date(event.date) >= new Date());

        // Sort events in decreasing order of dates
        filteredEvents.sort((a, b) => {
          if (new Date(a.date) > new Date(b.date)) return 1;
          if (new Date(a.date) < new Date(b.date)) return -1;
          // If dates are the same, sort in decreasing order of time
          if (a.time > b.time) return 1;
          if (a.time < b.time) return -1;
          return 0;
        });

        setEvents(filteredEvents);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  return (
    <div className='events'>
      <h2>Our Events</h2>
      <marquee className='marquee' direction='up' scrollamount='3' height='300' behavior='scroll'>
        {Array.isArray(events) && events.map(event => (
          <div key={event._id} className='event'>
            <h2>{event.event}</h2>
            <h3>{event.date}</h3>
            <h4>{event.time}</h4>
            <p>{event.message}</p>
          </div>
        ))}
      </marquee>
    </div>
  );
};

export default Events;

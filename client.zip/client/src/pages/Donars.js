import React, { useState, useEffect } from 'react';
import './Donars.css';
import axios from 'axios';

const Donars = () => {
  const [donations, setDonations] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:3000/donations')
      .then(response => {
        setDonations(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);




  return (
    <div className='donars-page'>
    <div className='donars'>
      <h2 className='head'>Donors List</h2><br/><br/>
      <div className='row'>
        {donations.map(donation => (
          <div key={donation._id} className='col'>
            <div className='card'>
              {donation.image && <img src={`http://localhost:3000/uploads/${donation.image}`} className='card-img-top' alt={donation.fname} />}
              <div className='card-body'>
                <h5 className='card-title'>{donation.fname}</h5>
                <p className='card-text'>{donation.city}</p>
                <p className='card-amount'>₹ {donation.amount}</p>
              </div>
            </div>
          </div>
        ))}
      </div><br/><br/>
      <div className='footer2'>
  <div class="flex-container2">
    <p className='p1'>Email: info@temple.com</p>
    <p className='p2'>Phone: +1234567890</p>
    <p className='p3'>Address: 123 Temple Street, City, Country</p>
  </div>
  <p>Connect with us:</p>
  <div className="social-links2">
    <a href="https://twitter.com/temple" target="_blank" rel="noopener noreferrer">Twitter</a>
    <a href="https://facebook.com/temple" target="_blank" rel="noopener noreferrer">Facebook</a>
    <a href="https://instagram.com/temple" target="_blank" rel="noopener noreferrer">Instagram</a>
  </div>
  <p>Your support helps us maintain and improve our services. <a href="/donation">Donate Now</a></p>
</div>
     </div>
    </div>
  );
}

export default Donars;


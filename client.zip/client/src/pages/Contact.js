import React,{useState} from 'react';
import Kumar from '../Images/Kumar.webp';
import Rani from '../Images/Rani.png'
import Deva from '../Images/Deva.jpg'
import './Contact.css';
import axios from 'axios'

const Contact = () => {
  const [name,setName]=useState('')
  const [phone,setPhone]=useState('')
  const [message,setMessage]=useState('')

  const queryHandler = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post('http://localhost:3000/contact', { name, phone, message });
      alert('Your query has been submitted successfully.');
      // Clear the form fields
      setName('');
      setPhone('');
      setMessage('');
    } catch (error) {
      console.error('Error submitting the form:', error);
      alert('There was an error submitting your query. Please try again.');
    }
  };
  return (
    <div className='contact-page'>
      <h1 className='off'>Temple Location</h1><br/><br/>
      <div className='location'>
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3869.448271938686!2d78.15255627486293!3d14.109714986320542!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb3cf9bf9e37d99%3A0x11b3286b45357aa3!2sKadiri%20Lakshmi%20Narasimha%20Swamyvari%20Temple!5e0!3m2!1sen!2sin!4v1716629132397!5m2!1sen!2sin"
          width="600"
          height="450"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Kadiri Lakshmi Narasimha Swamyvari Temple"
        ></iframe>
      </div>
      <div className='officials'>
        <h1 className='off'>Temple Officials</h1>
        <div className='official'>
          <img src={Kumar} alt='official1'/>
          <div className='content'>
            <h1>Kumar</h1>
            <p>Temple Administrator</p>
            <p className='phone'><span>Call:</span>9581918823</p>
          </div>
        </div>
        <div className='official'>
          <img src={Deva} alt='official2'/>
          <div className='content'>
            <h1>Deva</h1>
            <p>Temple Secretary</p>
            <p className='phone'><span>Call:</span>9876543210</p>
          </div>
        </div>
        <div className='official'>
          <img src={Rani} alt='official3'/>
          <div className='content'>
            <h1>Rani</h1>
            <p>Event Coordinator</p>
            <p className='phone'><span>Call:</span>8309614542</p>
          </div>
        </div>
      </div>
      <div className='query'>
        <h1 className='off'>Query Form</h1>
        <div className='form-container'>
        <form onSubmit={queryHandler}>
          <input type='text' placeholder='Enter Your Name' name='name' value={name} autoComplete='off' required onChange={(e)=>setName(e.target.value)}/>
          <input type='tel' placeholder='Enter Your Phone Number' name='phone' value={phone} autoComplete='off' required onChange={(e)=>setPhone(e.target.value)}/>
          <textarea name='message' rows="3" cols="50" value={message} placeholder='Enter Your Query' onChange={(e)=>setMessage(e.target.value)}></textarea>
          <button>Submit</button>
        </form>
        </div>
      </div>
      <div className='footer4'>
  <div class="flex-container4">
    <p className='p1'>Email: info@temple.com</p>
    <p className='p2'>Phone: +1234567890</p>
    <p className='p3'>Address: 123 Temple Street, City, Country</p>
  </div>
  <p>Connect with us:</p>
  <div className="social-links4">
    <a href="https://twitter.com/temple" target="_blank" rel="noopener noreferrer">Twitter</a>
    <a href="https://facebook.com/temple" target="_blank" rel="noopener noreferrer">Facebook</a>
    <a href="https://instagram.com/temple" target="_blank" rel="noopener noreferrer">Instagram</a>
  </div>
  <p>Your support helps us maintain and improve our services. <a href="/donation">Donate Now</a></p>
</div>
    </div>
  );
}

export default Contact;

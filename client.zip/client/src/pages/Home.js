import React from 'react';
import {Link} from 'react-router-dom'
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './Home.css';
import Kadiri from '../Images/Kadiri.webp'


const Home = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000, 
    cssEase: 'linear'
  };

  return (
    <div className='container'>
      <div className='carousel-container'>
      <Slider {...settings}>
        <div className="slide">
          <img src={require('../Images/Kadiri.webp')} alt="Slide 1" />
        </div>
        <div className="slide">
          <img src={require('../Images/slider1.jpg')} alt="Slide 2" />
        </div>
        <div className="slide">
          <img src={require('../Images/slider2.jpg')} alt="Slide 3" />
        </div>
        <div className="slide">
          <img src={require('../Images/slider3.jpg')} alt="Slide 4" />
        </div>
        <div className="slide">
          <img src={require('../Images/slider4.webp')} alt="Slide 5" />
        </div>
        <div className="slide">
          <img src={require('../Images/slider5.jpg')} alt="Slide 6" />
        </div>
      </Slider>
      </div><br/><br/>
      <div className='about-div shadow-lg'>
        <h2 className='head'>Temple History & Details</h2>
        
        <div className='about-text-div '>
            <h5>
                     It is known from the inscriptions on the Temple walls, that Swamy appeared in the dream of Veera Bukka Rayalu of Vijayanagar dynasty and revealed his whereabouts. King along with his staff then recovered the Idol (Saligramam) from the roots of the tree and built the temple.
                As time passes, the Idol disappeared from the temple, Lord Narasimha Swamy appeared in the dreams of Achyutha Devarayulu and revealed his whereabouts. King brought the idol from Sthothadhri hill caves and installed in the temple.

                Cholas, during 985 – 1076 A.D built the temple for Durga Devi Temple and sculptured idols on the rocks. In the year 1953, Lakshmi idol was installed in the place of Durga Devi, still, we can see Dura Devi main idol inside Durga Devi temple.
            </h5>
        </div>
        <div className='about-table-div'>

            <table class="table">
                <thead class="thead-light">
                    <tr>
                    
                    <th scope="col">Phase</th>
                    <th scope="col">Construction Details</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                   
                    <td>First Phase</td>
                    <td>Bukka Raya I completed Gopuram Construction in 1353 AD</td>
                    </tr>
                    <tr>
                    
                    <td>Second Phase</td>
                    <td>	Harihara Raya made additions during 1356 – 1418 AD</td>
                    </tr>
                    <tr>
                    
                    <td>Third Phase</td>
                    <td>Sri Krishna Devaraya renovated in 1509 – 1529 AD</td>
                    </tr>
                </tbody>
            </table>
            
        </div>  
      </div>
            <div class='new-container'>
  <div class='daily-schedule'>
    <h2>Daily Schedule</h2>
    <div class="schedule-wrapper">
      <marquee behavior="scroll" direction="up" scrollamount="2">
        <ul class="schedule">
          <li>Temple Opening: 5.00 AM</li>
          <li>Suddhi: 5.00 AM to 5.30 AM</li>
          <li>Prathakala Archana: 5.30 AM to 6.00 AM</li>
          <li>ChaturVeda Mantra Harathi: 6.00 AM to 6.30 AM</li>
          <li>Sarva Darshan: 6.30 AM to 7.30 AM</li>
          <li>Panchamrutha Nithya Abhishekam: 7.30 AM to 10.00 AM</li>
          <li>Sarva Darshan: 10.00 AM to 12.00 PM</li>
          <li>Madhyanakala Archana: 12.00 PM to 12.30 PM</li>
          <li>Sarva Darshan: 12.30 PM to 1.00 PM</li>
          <li>Temple closing hours: 1.00 PM to 4.30 PM</li>
          <li>Temple re-opening hours: 4.30 PM</li>
          <li>Sarva Darshan: 4.30 PM to 6.30 PM</li>
          <li>Sayankala Archana: 6.30 PM - 7.00 PM</li>
          <li>Chaturveda Ghosti: 7.00 PM to 7.30 PM</li>
          <li>Sarva Darshan: 7.30 PM to 8.30 PM</li>
          <li>Temple Closing: 8.30 PM</li>
        </ul>
      </marquee>
    </div>  
  </div>
  <div class='book'>
    <img src={Kadiri} alt='here'/>
    <Link to="/darshan"><button>Book Slots</button></Link>
  </div>
</div><br/><br/>
<div className='footer'>
  <div class="flex-container">
    <p className='p1'>Email: info@temple.com</p>
    <p className='p2'>Phone: +1234567890</p>
    <p className='p3'>Address: 123 Temple Street, City, Country</p>
  </div>
  <p>Connect with us:</p>
  <div className="social-links">
    <a href="https://twitter.com/temple" target="_blank" rel="noopener noreferrer">Twitter</a>
    <a href="https://facebook.com/temple" target="_blank" rel="noopener noreferrer">Facebook</a>
    <a href="https://instagram.com/temple" target="_blank" rel="noopener noreferrer">Instagram</a>
  </div>
  <p>Your support helps us maintain and improve our services. <a href="/donation">Donate Now</a></p>
</div>



    </div>
    
  )
}

export default Home
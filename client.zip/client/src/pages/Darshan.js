import React, { useState, useEffect } from 'react';
import './Darshan.css';
import axios from 'axios';

const Darshan = () => {
  const [name, setName] = useState('');
  const [ticket, setTicket] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [date, setDate] = useState('');
  const [slot, setSlot] = useState('');
  const [amount, setAmount] = useState(0);
  const [qrCode, setQrCode] = useState(null);
  const [timer, setTimer] = useState(60);
  const [showDialog, setShowDialog] = useState(false);
  const [minDate, setMinDate] = useState('');
  const [availableSlots, setAvailableSlots] = useState([]);
  const [slotBookings, setSlotBookings] = useState({});

  const slots = ['08:00', '09:00', '10:00', '11:00', '18:00', '19:00'];

  useEffect(() => {
    if (ticket) {
      setAmount(parseInt(ticket) * 100);
    } else {
      setAmount(0);
    }
  }, [ticket]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setMinDate(today);
  }, []);

  useEffect(() => {
    const today = new Date();
    const selectedDate = new Date(date);
    const currentHour = today.getHours();
    const currentMinute = today.getMinutes();
    const filteredSlots = slots.filter(slot => {
      const [hour, minute] = slot.split(':').map(Number);
      const isTimeValid =
        date !== minDate ||
        (hour > currentHour || (hour === currentHour && minute >= currentMinute));
      const bookingsForDate = slotBookings[date] || {};
      const isWithinLimit = (bookingsForDate[slot] || 0) < 10;
      return isTimeValid && isWithinLimit;
    });

    setAvailableSlots(filteredSlots);
  }, [date, minDate, slotBookings]);

  const submitHandler = async e => {
    e.preventDefault();

    const formData = {
      name,
      ticket,
      email,
      mobile,
      date,
      slot,
      amount
    };

    const totalTickets = parseInt(ticket);
    const bookingsForDate = slotBookings[date] || {};
    const currentBookings = bookingsForDate[slot] || 0;

    if (currentBookings + totalTickets > 10) {
      alert(
        'The selected number of tickets exceeds the available slots for the selected time.'
      );
      return;
    }

    try {
      const result = await axios.post('http://localhost:3000/darshan', formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      setQrCode(result.data.qrCode);
      setTimer(60);

      setSlotBookings(prevBookings => {
        const updatedBookingsForDate = {
          ...bookingsForDate,
          [slot]: currentBookings + totalTickets
        };
        return {
          ...prevBookings,
          [date]: updatedBookingsForDate
        };
      });
    } catch (err) {
      console.error('Error submitting darshan details:', err.message);
      console.error('Server Response:', err.response.data);
      alert('Error submitting darshan details. Please try again later.');
    }
  };

  useEffect(() => {
    let countdown;
    if (qrCode && timer > 0) {
      countdown = setInterval(() => {
        setTimer(prevTimer => prevTimer - 1);
      }, 1000);
    } else if (timer === 0) {
      setShowDialog(true);
    }
    return () => clearInterval(countdown);
  }, [qrCode, timer]);

  const handleOkClick = async () => {
    alert(
      'Your booking is under process. We will check and update your booking.'
    );
    setName('');
    setTicket('');
    setEmail('');
    setMobile('');
    setDate('');
    setSlot('');
    setAmount(0);
    setQrCode(null);
    setShowDialog(false);
    try {
      await axios.post('http://localhost:3000/sms', {
        name,
        mobile:'+91'+mobile,
        date,
        slot
      });
    } catch (error) {
      console.error('Error sending SMS:', error);
      alert('Error sending SMS. Please try again later.');
    }
  };
  return (
    <div className='darshan'>
      <h1 className='head'>Book Slots for Darshan</h1>
      <div className='form-container'>
        <form onSubmit={submitHandler} autoComplete='off'>
          <input
            type='text'
            placeholder='Enter Your Name'
            name='name'
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete='off'
            required
          />
          <select
            value={ticket}
            onChange={(e) => setTicket(e.target.value)}
            required
          >
            <option value=''>Select Total Tickets</option>
            <option value='1'>1 Ticket</option>
            <option value='2'>2 Tickets</option>
            <option value='3'>3 Tickets</option>
            <option value='4'>4 Tickets</option>
            <option value='5'>5 Tickets</option>
            <option value='6'>6 Tickets</option>
          </select>
          <input
            type='email'
            placeholder='Enter Your Mail'
            name='email'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='tel'
            placeholder='Enter Your Mobile Number'
            name='mobile'
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='date'
            name='date'
            value={date}
            onChange={(e) => setDate(e.target.value)}
            min={minDate}
            required
          />
          <select
            value={slot}
            onChange={(e) => setSlot(e.target.value)}
            required
          >
            <option value=''>Select Slot Timings</option>
            {slots.map(slot => (
              <option key={slot} value={slot} disabled={!availableSlots.includes(slot)}>
                {slot}
              </option>
            ))}
          </select>
          <input
            type='number'
            placeholder='Enter Total Amount'
            name='amount'
            value={amount}
            readOnly // Make the amount field read-only
            required
          />
          <button type='submit'>Book Now</button>
        </form>
        {qrCode && (
          <div className='qr-code'>
            <h2>Scan the QR code to complete your payment</h2>
            <img src={qrCode} alt="QR Code" />
            {timer > 0 ? (
              <div className='timer'>Time left: {timer} seconds</div>
            ) : (
              showDialog && (
                <div className='dialog'>
                  <p>Thank you for your booking. We will check your payment status.</p>
                  <button onClick={handleOkClick}>OK</button>
                </div>
              )
            )}
          </div>
        )}
      </div><br/><br/>
      <div className='footer3'>
        <div className='flex-container3'>
          <p className='p1'>Email: info@temple.com</p>
          <p className='p2'>Phone: +1234567890</p>
          <p className='p3'>Address: 123 Temple Street, City, Country</p>
        </div>
        <p>Connect with us:</p>
        <div className="social-links3">
          <a href="https://twitter.com/temple" target="_blank" rel="noopener noreferrer">Twitter</a>
          <a href="https://facebook.com/temple" target="_blank" rel="noopener noreferrer">Facebook</a>
          <a href="https://instagram.com/temple" target="_blank" rel="noopener noreferrer">Instagram</a>
        </div>
        <p>Your support helps us maintain and improve our services. <a href="/donation">Donate Now</a></p>
      </div>
    </div>
  );
};

export default Darshan;

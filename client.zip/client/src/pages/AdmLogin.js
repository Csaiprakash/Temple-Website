import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdmLogin.css';

const AdmLogin = ({ setIsLoggedIn }) => {
  const handleusername = 'saiprakash';
  const handlepassword = 'sai@2244';

  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [password, setPassword] = useState('');

  const handler = (e) => {
    e.preventDefault();
    if (name === handleusername && password === handlepassword) {
      alert('Login Successful');
      setIsLoggedIn(true);  // Update the state to reflect that the user is logged in
      navigate('/addevent');
    } else {
      alert('Error Occurred');
    }
  };

  

  return (
    <div className='admin'>
      <div className='heading'>Admin Login</div>
      <div className='login-container'>
        <form onSubmit={handler}>
          <input 
            type='text'
            placeholder='Enter Username'
            required
            name='name'
            autoComplete='off'
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type='password'
            placeholder='Enter Password'
            required
            name='password'
            autoComplete='off'
            onChange={(e) => setPassword(e.target.value)}
          />
          <button>Login</button>
        </form>
      </div>
    </div>
  );
};

export default AdmLogin;

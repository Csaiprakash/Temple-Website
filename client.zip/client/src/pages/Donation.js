import React, { useState, useRef, useEffect } from 'react';
import './Donation.css';
import axios from 'axios';

const Donation = () => {
  const [fname, setFname] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [amount, setAmount] = useState('');
  const [image, setImage] = useState(null);
  const [qrCode, setQrCode] = useState(null);
  const [timer, setTimer] = useState(60);
  const [showDialog, setShowDialog] = useState(false);
  const fileInputRef = useRef(null);

  const submitHandler = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('fname', fname);
    formData.append('mobile', mobile);
    formData.append('email', email);
    formData.append('city', city);
    formData.append('amount', amount);
    if (image) {
      formData.append('image', image);
    }

    try {
      const result = await axios.post('http://localhost:3000/donation', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setQrCode(result.data.qrCode);
      setTimer(60);
    } catch (err) {
      console.error('Error submitting donation:', err.message);
      console.error('Server Response:', err.response.data);
      alert('Error submitting donation. Please try again later.');
    }
  };

  useEffect(() => {
    let countdown;
    if (qrCode && timer > 0) {
      countdown = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    } else if (timer === 0) {
      setShowDialog(true);
    }
    return () => clearInterval(countdown);
  }, [qrCode, timer]);

  const handlePaymentSuccess = () => {
    alert('Payment Successful');
    setFname('');
    setMobile('');
    setEmail('');
    setCity('');
    setAmount('');
    setImage(null);
    setQrCode(null);
    setTimer(60);
    setShowDialog(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleOkClick = () => {
    setQrCode(null);
    setFname('');
    setMobile('');
    setEmail('');
    setCity('');
    setAmount('');
    setImage(null);
    setShowDialog(false);
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  return (
    <div className='donate'>
      <h1 className='head'>Donate Now</h1>
      <div className='form-container'>
        <form onSubmit={submitHandler} autoComplete='off'>
          <input
            type='text'
            placeholder='Enter Full Name'
            name='name'
            value={fname}
            onChange={(e) => setFname(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='tel'
            placeholder='Enter Mobile Number'
            name='mobile'
            pattern="[0-9]{10}"
            title="Mobile number should be exactly 10 digits"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='email'
            placeholder='Enter Mail ID'
            name='email'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='text'
            placeholder='Enter City Name'
            name='city'
            value={city}
            onChange={(e) => setCity(e.target.value)}
            autoComplete='off'
            required
          />
          <input
            type='number'
            placeholder='Enter Total Amount'
            name='amount'
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            autoComplete='off'
            required
            min="1"
          />
          <label className='form-image' htmlFor="image">Upload your image</label>
          <input
            type='file'
            id='image'
            name='image'
            accept='image/*'
            ref={fileInputRef}
            className='file-input'
            onChange={(e) => setImage(e.target.files[0])}
          />
          <button type='submit'>Generate QR Code</button>
        </form>
        {qrCode && (
          <div className='qr-code'>
            <h2>Scan the QR code to complete your payment</h2>
            <img src={qrCode} alt="QR Code" />
            {timer > 0 ? (
              <div className='timer'>Time left: {timer} seconds</div>
            ) : (
              showDialog && (
                <div className='dialog'>
                  <p>Thank you for your donation. We will check your donation.</p>
                  <button onClick={handleOkClick}>OK</button><br/><br/>
                </div>
              )
            )}
          </div>
        )}
      </div><br/><br/>
      <div className='footer1'>
  <div class="flex-container1">
    <p className='p1'>Email: info@temple.com</p>
    <p className='p2'>Phone: +1234567890</p>
    <p className='p3'>Address: 123 Temple Street, City, Country</p>
  </div>
  <p>Connect with us:</p>
  <div className="social-links1">
    <a href="https://twitter.com/temple" target="_blank" rel="noopener noreferrer">Twitter</a>
    <a href="https://facebook.com/temple" target="_blank" rel="noopener noreferrer">Facebook</a>
    <a href="https://instagram.com/temple" target="_blank" rel="noopener noreferrer">Instagram</a>
  </div>
  <p>Your support helps us maintain and improve our services. <a href="/donation">Donate Now</a></p>
</div>
    </div>
  );
};

export default Donation;

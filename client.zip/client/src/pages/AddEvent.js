import React,{useState,useEffect} from 'react'
import './AddEvent.css'
import axios from 'axios'
const AddEvent = () => {
  const[event,setEvent]=useState('')
  const [date,setDate]=useState('')
  const [time,setTime]=useState('')
  const [message,setMessage]=useState('')
  const [minDate,setMinDate]=useState('')

  const eventHandler=(e)=>{
    e.preventDefault()
    const result=axios.post('http://localhost:3000/addevent',{event,date,time,message})
    console.log(result)
    alert('Event is Added!!')
    setEvent('')
    setDate('')
    setTime('')
    setMessage('')
  }

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setMinDate(today);
  }, []);


  return (
    <div className='events'>
      <div className='title'>
        <h1>Add New Events</h1>
      </div>
      <div className='event-form'>
        <form onSubmit={eventHandler}>
          <input type='text' placeholder='Enter Event Name' name='event' value={event} required autoComplete='off'onChange={(e)=>setEvent(e.target.value)}/>
          <input type='date' name='date' value={date} required autoComplete='off' onChange={(e)=>setDate(e.target.value)} min={minDate}/>
          <input type='time' name='time' value={time} required autoComplete='off' onChange={(e)=>setTime(e.target.value)}/>
          <textarea placeholder='Enter the details about the event' name='message' value={message} rows='2' cols='50' autoComplete='off' required onChange={(e)=>setMessage(e.target.value)}></textarea>
          <button>Add Event</button>
        </form>
      </div>
    </div>
  )
}

export default AddEvent